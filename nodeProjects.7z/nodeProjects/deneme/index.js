console.log("helllo  node gusyys")


const fs=require("fs")

require("./utils.js")
fs.writeFileSync("notes.txt","hellooooo ppppdpfdpfdfqqqqqqqqqqqqqqqqqqqqqqqqqqqj\n")


fs.appendFileSync("notes.txt","hellooooo ppppdpfdpfdfqqqqqqqqqqqqqqqqqqqqqqqqqqqj\n")


