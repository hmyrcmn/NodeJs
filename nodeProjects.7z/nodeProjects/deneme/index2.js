
const names=require("../nodesAPP/utils.js")
console.log(names)



// fonk karışlama utildsseden exoprt edilen 

const add_fun=require("../nodesAPP/utils.js")
const toplam=add_fun(10,20)

console.log(toplam)