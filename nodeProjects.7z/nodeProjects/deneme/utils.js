console.log("utils den hello ")

const names="humeyra"
module.exports=names

// utils modfulundfaki name index dosyasına export etmek gerek ve fonk donuşu gibi karşılam olmalı


// fonksiyonun export edilmesi 

// fonksiyon tanımlama
const add =function (a,b) {return a+b}
module.exports=add