// fonksiyon tanımlama
const myfunk =function () {return "hello from note.js funk "}
module.exports=myfunk